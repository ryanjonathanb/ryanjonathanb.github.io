# y_describe.py
# A parser to describe historical adjusted price data from Yahoo Finance's CSV file. Requires pandas to be installed. Matplotlib required for plotting.
# Coded and valid as of 24 Aug 2016. Any format change by Yahoo may necessitate a tweak to the script.
"""
y_describe.py - a Python parser for Yahoo!(tm) Finance historical CSV file.
Copyright (C) 2016 Ryan Jonathan Budiman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>."""

from sys import argv
import os
import pandas
import numpy

### Begin function ###

def y_describe(path_to_file):
    print "The file we're looking at is: %r" % path_to_file

    # Read CSV file, transform into panda dataframe
    table = pandas.read_csv(path_to_file)

    # Take only the Adj Close column.
    table = table['Adj Close']

    # Find percentage change between two adjacent prices.
    table_chg = table.pct_change()

    # Convert Nan to integer 0.
    table_chg[0] = 0

    # Finding Value At Risk
    var95 = table_chg.mean() - (1.65 * table_chg.std())
    var99 = table_chg.mean() - (2.33 * table_chg.std())

    str_var95 = "VAR95: %s" % round(var95, 6)
    str_var99 = "VAR99: %s" % round(var99, 6)

    result = "%s \n\n%s \n%s" % (table_chg.describe(), str_var95, str_var99)

    return table, table_chg, result

#def plot(a):
    #import matplotlib
    #a.plot.hist(alpha=0.5)
    #matplotlib.pyplot.show()
    #return

def save_to_file(data):
    return


def show_license():
    global script_version
    gnu_license = """
    a Python parser for Yahoo!(tm) Finance historical CSV file.
    Copyright (C) 2016 Ryan Jonathan Budiman.

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
    """ 
    print gnu_license
    return

### End of function ###

script_version = "v.0.2.5"
print "y_describe.py %s" % script_version

# Unpacking arguments
try:
    script_name, script_arg = argv
except ValueError:
    script_arg = raw_input("Path to the file we're working with > ")

# Parser for arguments
if script_arg == "--license":
    show_license()
    raise SystemExit
else:
    False

# Check if file exists.
i = os.path.isfile(script_arg)

while not i:
    print "File doesn't exist."
    script_arg = raw_input("Try a new file path > ")

    i = os.path.isfile(script_arg)

print "Gotcha. Starting script...\n"

# Run, then take the output of y_describe()
table, table_chg, result = y_describe(script_arg)

# Print the description table
print "[Percent changes of daily prices]"
print "in full numbers (0.01 = 1%), except count"
print "%s\n" % result

choose_plot = raw_input("Plot histogram? y/n > ")

if choose_plot.lower() in ("y", "yes", "ok"):
    import matplotlib
    hist = table_chg.plot.hist(alpha=0.6, bins=80, figsize=(20,8))
    kde = table_chg.plot.kde()
    title = "Frequencies of percent changes of adjusted price from " + script_arg
    matplotlib.pyplot.title(title)
    matplotlib.pyplot.show(hist)
else:
    False
